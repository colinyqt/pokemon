// images.h
// contains image buffers for simple space invaders
// Jonathan Valvano, March 5, 2018
// Capture image dimensions from BMP files

#ifndef __images_h
#define __images_h



// *************************** Images ***************************
// enemy ship that starts at the top of the screen (arms/mouth closed)
// includes two blacked out columns on the left and right sides of the image to prevent smearing when moved 2 pixels to the left or right
// includes one blacked out row on the top and bottom sides of the image to prevent smearing when moved 1 pixels to the up or down
// width=16 x height=10

//player

struct npc {
    uint32_t x[8];
    uint32_t y[8];
    const uint16_t *sprites[8];
};

extern const unsigned short brendan1[];
extern const unsigned short brendan2[];
extern const unsigned short brendanleft[];
extern const unsigned short brendanright[];
extern const unsigned short brendan1run[];
extern const unsigned short brendan2run[];
extern const unsigned short brendanleftrun[];
extern const unsigned short brendanrightrun[];
extern const unsigned short exclaim[];
extern const unsigned short gengarSprite[];
extern const unsigned short gengarback[];
extern const unsigned short pokbal[];
extern const unsigned short pokbal2[];


extern struct npc brendan;

//bg
extern const unsigned short npcmap[];


#endif /* __images_h */
